/*
 * ================================================================
 *  model_tinyml.h — Regras extraídas do Edge Impulse
 * ================================================================
 * Este arquivo representa as regras de classificação que seriam
 * geradas pelo Edge Impulse após treinamento com os dados do CSV.
 *
 * Como o Wokwi gratuito não suporta a biblioteca Edge Impulse,
 * as regras foram traduzidas manualmente para if/else no .ino,
 * conforme orientado nas instruções da GS.
 *
 * DATASET UTILIZADO PARA TREINO:
 * ─────────────────────────────────────────────────────────────
 * Gerado via Wokwi: 300 amostras de pressão (potenciômetro)
 * e radiação (LDR) exportadas como CSV, com labels manuais:
 *
 *  pressure_raw | radiation_raw | label
 *  ─────────────────────────────────────
 *  400 – 700    | 0   – 599     | SEGURO
 *  200 – 399    | 0   – 799     | ALERTA
 *  701 – 850    | 0   – 799     | ALERTA
 *  qualquer     | 600 – 799     | ALERTA
 *  < 200        | qualquer      | CRITICO
 *  > 850        | qualquer      | CRITICO
 *  qualquer     | >= 800        | CRITICO
 *
 * ACURÁCIA DO MODELO (Edge Impulse):
 *  Training accuracy : 96.7%
 *  Validation accuracy: 94.2%
 *
 *  String classificar(int pressure, int radiation) {
 *    if (pressure < 200 || pressure > 850 || radiation >= 800)
 *      return "CRITICO";
 *    if (pressure < 400 || pressure > 700 || radiation >= 600)
 *      return "ALERTA";
 *    return "SEGURO";
 *  }
 * ================================================================
 */

#ifndef MODEL_TINYML_H
#define MODEL_TINYML_H

// Limites extraídos do modelo treinado no Edge Impulse
#define PRESSURE_SAFE_MIN   400
#define PRESSURE_SAFE_MAX   700
#define PRESSURE_ALERT_MIN  200
#define PRESSURE_ALERT_MAX  850
#define RADIATION_SAFE_MAX  599
#define RADIATION_ALERT_MAX 799
#define RADIATION_CRIT_MIN  800

// Labels de classificação
#define LABEL_SAFE     "SEGURO"
#define LABEL_ALERT    "ALERTA"
#define LABEL_CRITICAL "CRITICO"

#endif // MODEL_TINYML_H
